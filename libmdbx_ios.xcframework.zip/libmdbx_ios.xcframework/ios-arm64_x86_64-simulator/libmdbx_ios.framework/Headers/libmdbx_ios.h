//
//  libmdbx_ios.h
//  libmdbx-ios
//
//  Created by Mikhail Nikanorov on 4/7/21.
//

#import <Foundation/Foundation.h>

//! Project version number for libmdbx_ios.
FOUNDATION_EXPORT double libmdbx_iosVersionNumber;

//! Project version string for libmdbx_ios.
FOUNDATION_EXPORT const unsigned char libmdbx_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libmdbx_ios/PublicHeader.h>

#import <libmdbx_ios/mdbx.h>
